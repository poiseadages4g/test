export default function Home() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>ABL Bundle to MIDI Converter</h1>
      <input type="file" id="upload" accept=".ablbundle" />
      <p id="status">Upload a .ablbundle file</p>
      <a id="downloadLink" style={{ display: 'none' }} download="drumrack_bundle.zip">Download Bundle</a>
      <script
        dangerouslySetInnerHTML={{
          __html: `
            document.getElementById('upload').addEventListener('change', async (e) => {
              const file = e.target.files[0];
              if (!file) return;
              document.getElementById('status').textContent = 'Processing...';
              const formData = new FormData();
              formData.append('file', file);
              const res = await fetch('/api/convert', { method: 'POST', body: formData });
              if (res.ok) {
                const blob = await res.blob();
                const url = URL.createObjectURL(blob);
                const link = document.getElementById('downloadLink');
                link.href = url;
                link.style.display = 'inline-block';
                document.getElementById('status').textContent = '✅ Ready!';
              } else {
                document.getElementById('status').textContent = 'Error during conversion.';
              }
            });
          `,
        }}
      />
    </div>
  );
}
