import formidable from 'formidable';
import AdmZip from 'adm-zip';
import { Midi } from '@tonejs/midi';
import JSZip from 'jszip';

export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  const form = new formidable.IncomingForm({ multiples: false });
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).send('Upload error');

    try {
      const file = files.file[0];
      const zip = new AdmZip(file.filepath);
      const entry = zip.getEntry('Song.abl');
      if (!entry) return res.status(400).send('Missing Song.abl');

      const song = JSON.parse(entry.getData().toString('utf-8'));
      const chains = song?.tracks?.[0]?.devices?.[0]?.chains?.[0]?.devices?.[0]?.chains || [];
      const clipSlots = song?.tracks?.[0]?.clipSlots || [];

      const pads = chains.map(c => ({
        note: c.drumZoneSettings?.receivingNote,
        sampleUri: c.devices?.[0]?.deviceData?.sampleUri
      })).filter(p => p.note !== undefined && p.sampleUri);

      const noteMap = new Map();
      for (const slot of clipSlots) {
        const notes = slot.clip?.notes || [];
        for (const n of notes) {
          const group = noteMap.get(n.noteNumber) || [];
          group.push(n);
          noteMap.set(n.noteNumber, group);
        }
      }

      const outZip = new JSZip();
      for (const pad of pads) {
        const name = decodeURIComponent(pad.sampleUri.split('/').pop());
        const renamed = `${pad.note}-${name}`;
        const sample = zip.getEntry(pad.sampleUri);
        if (sample) outZip.file(renamed, sample.getData());

        if (noteMap.has(pad.note)) {
          const midi = new Midi();
          const track = midi.addTrack();
          for (const n of noteMap.get(pad.note)) {
            track.addNote({ midi: n.noteNumber, time: n.startTime, duration: n.duration, velocity: n.velocity / 127 });
          }
          outZip.file(name.replace(/\.[^.]+$/, '.mid'), Buffer.from(midi.toArray()));
        }
      }

      const zipped = await outZip.generateAsync({ type: 'nodebuffer' });
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="drumrack_bundle.zip"');
      res.send(zipped);
    } catch (e) {
      console.error(e);
      res.status(500).send('Processing error');
    }
  });
}
